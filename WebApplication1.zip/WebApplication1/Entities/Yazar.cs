﻿namespace WebApplication1.Entities
{
    public class Yazar
    {
        public int ID { get; set; }
        public string AD { get; set; }
        public string SOYAD { get; set; }
        public string  DETAY { get; set; }

    }
}
