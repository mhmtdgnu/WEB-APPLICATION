﻿namespace WebApplication1.Entities
{
    public class Prosedür
    {
        public string EnAktifKisi { get; set; }
        public string EnCokOkunanKitap { get; set; }
        public string EnFazlaKitapYazarı { get; set; }
        public string EnİyiYayınEvi { get; set; }
        public string EnAktifPersonel { get; set; }
        public string BugununEmanetleri { get; set; }
    }
}
