﻿namespace WebApplication1.Entities
{
    public class Kategori
    {
        public byte ID { get; set; }
        public string AD { get; set; }
        public Nullable<bool> DURUM { get; set; }
    }
}
