﻿namespace WebApplication1.Entities
{
    public class Iletisim
    {
        public int ID { get; set; }
        public string AD { get; set; }
        public string MAIL { get; set; }
        public string KONU { get; set; }
        public string MESAJ { get; set; }
    }
}
