﻿namespace WebApplication1.Entities
{
    public class Hakkımızda
    {
        public byte ID { get; set; }
        public string ACIKLAMA { get; set; }
    }
}
