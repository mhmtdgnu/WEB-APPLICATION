﻿namespace WebApplication1.Entities
{
    public class Personel
    {
        public byte ID { get; set; }
        public string PERSONEL { get; set; }
    }
}
