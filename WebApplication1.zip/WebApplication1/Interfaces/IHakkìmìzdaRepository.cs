﻿using WebApplication1.Entities;

namespace WebApplication1.Interfaces
{
    public interface IHakkımızdaRepository
    {
        public IEnumerable<Hakkımızda> GetHakkımızda();
    }
}
