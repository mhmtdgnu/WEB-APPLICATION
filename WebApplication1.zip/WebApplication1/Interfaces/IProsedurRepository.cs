﻿using WebApplication1.Entities;

namespace WebApplication1.Interfaces
{
    public interface IProsedurRepository
    {
        public Prosedür  GetProsedur();
    }
}
